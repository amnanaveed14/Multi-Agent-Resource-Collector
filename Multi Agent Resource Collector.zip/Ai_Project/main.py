import pygame
import random
import sys
import os
import math
import numpy as np

# --- CONFIGURATION & CONSTANTS ---
SCREEN_WIDTH = 1000 # The total width of the game window
SCREEN_HEIGHT = 720 # The total height of the game window
GRID_SIZE = 18 # 18x18 grid
CELL_SIZE = 40 # cell is 40 pixels wide
MAP_WIDTH = GRID_SIZE * CELL_SIZE 
MAP_HEIGHT = GRID_SIZE * CELL_SIZE 

# --- PALETTE ---
C_BG        = (10, 15, 30)     
C_GRID      = (30, 40, 60)    
C_WALL      = (40, 40, 80)    
C_WALL_EDGE = (0, 200, 255)     
C_PANEL     = (20, 25, 40)    
C_TEXT      = (220, 220, 255)   
C_ACCENT    = (0, 255, 200)    
C_NEON_PINK = (255, 0, 128)   
C_RED       = (255, 80, 80) # Color for the Greedy Agent
C_BLUE      = (80, 150, 255) # Color for the Cooperative Agent
C_GREEN     = (80, 255, 100) # Color for the Learning Agent
C_GOLD      = (255, 215, 0) 

# --- UTILITIES ---
def load_and_prep_image(filename, size):
    path = f"assets/{filename}" 
    if not os.path.exists(path): path = path.replace(".png", ".jpg")

    try:
        img = pygame.image.load(path) 
        img.set_colorkey((255, 255, 255)) 
        img = img.convert_alpha() 
        img = pygame.transform.smoothscale(img, (size, size))
        return img 
    except:
        surf = pygame.Surface((size, size))
        surf.fill(C_RED) 
        return surf 

def load_custom_font(size):
    """Tries to load Orbitron, falls back to system font."""
    possible_paths = [ 
        "assets/font/static/Orbitron-Bold.ttf",
        "assets/font/static/Orbitron-Regular.ttf",
        "assets/font/Orbitron-Bold.ttf",
        "assets/font/Orbitron-Regular.ttf",
        "assets/font/Orbitron.ttf"
    ]

    for path in possible_paths: 
        if os.path.exists(path): 
            try:
                return pygame.font.Font(path, size)
            except:
                continue 

    return pygame.font.SysFont("Arial Black", size)

class SoundManager:
    """Helper class to manage sounds safely."""
    def __init__(self):
        self.sounds = {} # Dictionary to store loaded sound objects
        self.sound_files = { 
            'pickup': 'pickup.wav',
            'start': 'start.wav',
            'complete': 'complete.wav'
        }
        self.load_sounds() 

    def load_sounds(self):
        for name, filename in self.sound_files.items():
            path = f"assets/{filename}"
            if not os.path.exists(path): path = f"assets/audio/{filename}" 

            if os.path.exists(path): 
                try:
                    sound = pygame.mixer.Sound(path) 
                    sound.set_volume(0.4)
                    self.sounds[name] = sound 
                except:
                    self.sounds[name] = None 
            else:
                self.sounds[name] = None 

    def play(self, name):
        if name in self.sounds and self.sounds[name]: # Checks if the sound exists and is loaded
            self.sounds[name].play() # Plays the sound effect

def draw_glow_text(surface, text, font, color, center_pos, glow_color=(0, 255, 255)):
    """Draws text with a multi-layer neon glow effect."""
    offsets = [(2, 2), (-2, -2), (2, -2), (-2, 2)] # Small offset positions for the glow layers
    for ox, oy in offsets: # Loops through the offsets
        glow_surf = font.render(text, True, (glow_color[0]//3, glow_color[1]//3, glow_color[2]//3)) # Renders a dim glow layer
        glow_rect = glow_surf.get_rect(center=(center_pos[0]+ox, center_pos[1]+oy)) 
        surface.blit(glow_surf, glow_rect) 

    main_surf = font.render(text, True, color) # Renders the main, bright text
    main_rect = main_surf.get_rect(center=center_pos)
    surface.blit(main_surf, main_rect) 
    return main_rect

# --- PARTICLE SYSTEM ---
class Particle:
    def __init__(self, x, y, color):
        self.x = x # Particle's starting X coordinate
        self.y = y # Particle's starting Y coordinate
        self.color = color 
        self.size = random.randint(2, 5) # Random initial size
        self.life = 1.0 # Life remaining, starting at 1
        angle = random.uniform(0, 6.28) # Random launch angle in radians (0 to 2*pi)
        speed = random.uniform(1, 4) # Random launch speed
        self.vx = math.cos(angle) * speed # Calculates velocity in the X direction
        self.vy = math.sin(angle) * speed # Calculates velocity in the Y direction

    def update(self):
        self.x += self.vx # Moves the particle horizontally
        self.y += self.vy # Moves the particle vertically
        self.life -= 0.05 # Decreases the particle's life 
        self.size *= 0.95 # Slowly shrinks the particle

    def draw(self, surface):
        if self.life > 0: # Only draw if the particle is still alive
            alpha_color = (*self.color, int(255 * self.life)) 
            surf = pygame.Surface((int(self.size)*2, int(self.size)*2), pygame.SRCALPHA) 
            pygame.draw.circle(surf, alpha_color, (int(self.size), int(self.size)), int(self.size)) 
            surface.blit(surf, (self.x - self.size, self.y - self.size)) 

# --- AGENT CLASS ---
class Agent:
    def __init__(self, grid_x, grid_y, img_name, name, color, strategy):
        self.grid_pos = [grid_x, grid_y] # Current position in grid units
        self.pixel_pos = [grid_x * CELL_SIZE, grid_y * CELL_SIZE] # Current position in pixels for smooth movement
        self.target_pixel = [grid_x * CELL_SIZE, grid_y * CELL_SIZE] 

        self.name = name 
        self.color = color 
        self.strategy = strategy # The AI type ("greedy", "coop", or "learning")
        self.score = 0 # Agent's current score
        self.previous_pos = [grid_x, grid_y] # Last position to prevent immediate backtracking

        self.image = load_and_prep_image(img_name, CELL_SIZE - 4) 

        # PATH VISUALIZATION
        self.trail = [] # List to store the center points of visited cells for the trail

        # Q-LEARNING MEMORY
        self.q_table = {} # Dictionary to store Q-values 
        self.alpha = 0.1   # Learning Rate 
        self.gamma = 0.9   # Discount Factor (how much the agent values future rewards)
        self.epsilon = 0.1 # Exploration Rate (probability of choosing a random move)

    def get_dist(self, p1, p2):
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]) # Calculates Manhattan distance

    def get_state(self, target):
        """Returns relative position (dx, dy) to target."""
        return (target[0] - self.grid_pos[0], target[1] - self.grid_pos[1]) # The state is the vector to the target

    def add_trail_point(self):
        """Adds current grid center to trail."""
        center_x = self.grid_pos[0] * CELL_SIZE + CELL_SIZE // 2 # Calculates center X in pixels
        center_y = self.grid_pos[1] * CELL_SIZE + CELL_SIZE // 2 # Calculates center Y in pixels
        self.trail.append((center_x, center_y)) 

    def update_visuals(self):
        speed = 0.2 # Smooth movement speed 
        diff_x = self.target_pixel[0] - self.pixel_pos[0] # Distance to target X
        self.pixel_pos[0] += diff_x * speed # Moves X position smoothly towards the target
        diff_y = self.target_pixel[1] - self.pixel_pos[1] # Distance to target Y
        self.pixel_pos[1] += diff_y * speed # Moves Y position smoothly towards the target

    def think_and_move(self, coins, agents, walls):
        if not coins: return # Stops the agent if all coins are collected

        # Convert coins and self position to NumPy arrays
        coins_arr = np.array(coins) # Converts coin positions to a NumPy array for fast calculation
        pos_arr = np.array(self.grid_pos) # Converts agent position to a NumPy array

        # Calculate Manhattan distance to ALL coins simultaneously
        # axis=1 sums |x1-x2| and |y1-y2| for each row
        distances = np.sum(np.abs(coins_arr - pos_arr), axis=1) # Fast calculation of all distances

        # --- STRATEGY 1: GREEDY ---
        if self.strategy == "greedy":
            # Use NumPy to find nearest coin index instantly
            nearest_idx = np.argmin(distances) # Finds the index of the smallest distance
            target_coin = coins[nearest_idx] # Selects the coin at that index
            self.move_towards(target_coin, walls) # Moves one step closer to the target coin

        # --- STRATEGY 2: COOPERATIVE ---
        elif self.strategy == "coop":
            best_coin = None # Placeholder for the chosen coin
            min_dist = float('inf') # Initializes minimum distance to infinity

            # Iterate through coins using the pre-calculated NumPy distances
            for i, coin in enumerate(coins): # Loops through all coins
                d = distances[i] # Current agent's distance to the coin
                taken = False # Flag to mark if another agent is closer

                # Check other agents
                for other in agents: # Loops through all other agents
                    if other != self: # Skips checking itself
                        od = self.get_dist(other.grid_pos, coin) # Other agent's distance to the coin
                        if od < d: taken = True # Another agent is strictly closer
                        elif od == d and other.name < self.name: taken = True # Tie-breaker: closest agent with a lexicographically smaller name gets it

                if not taken and d < min_dist: # If the coin is 'free' and closer than the current best coin
                    min_dist = d # Updates the minimum distance
                    best_coin = coin # Sets this as the new target

            if not best_coin: 
                # Fallback to nearest using NumPy if no free coin found
                nearest_idx = np.argmin(distances) # Reverts to simple Greedy (nearest coin)
                best_coin = coins[nearest_idx] # Selects the overall nearest coin

            self.move_towards(best_coin, walls) # Moves towards the chosen target

        # --- STRATEGY 3: LEARNING (Q-Learning) ---
        elif self.strategy == "learning":
            # Use NumPy to find nearest coin for state definition
            nearest_idx = np.argmin(distances) # Finds the nearest coin
            target_coin = coins[nearest_idx] # Sets the nearest coin as the target

            state = self.get_state(target_coin) # Defines the state as the relative vector (dx, dy) to the target

            # Init memory if new state
            if state not in self.q_table:
                self.q_table[state] = [0, 0, 0, 0] # Initializes Q-values for Up, Down, Left, Right actions

            if random.uniform(0, 1) < self.epsilon:
                action = random.randint(0, 3) # picks a random action
            else:
                action = self.q_table[state].index(max(self.q_table[state])) # picks the action with the highest known Q-value

            moves = [[0, -1], [0, 1], [-1, 0], [1, 0]] # Defines the moves for Up, Down, Left, Right
            dx, dy = moves[action] # Gets the chosen move vector

            old_dist = self.get_dist(self.grid_pos, target_coin) # Distance before moving
            nx, ny = self.grid_pos[0] + dx, self.grid_pos[1] + dy # Calculates the new position

            reward = -1 # Base negative reward for simply taking a step (time penalty)

            if [nx, ny] in walls or not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE): # Checks for wall collision or map boundary
                reward = -10 # Large negative penalty for hitting a wall
                nx, ny = self.grid_pos[0], self.grid_pos[1] # Resets position
            else:
                # Record path before moving
                self.add_trail_point() # Adds a point to the visual trail

                self.previous_pos = self.grid_pos[:] # Records the old position
                self.grid_pos = [nx, ny] # Updates to the new position
                new_dist = self.get_dist(self.grid_pos, target_coin) # Distance after moving

                if new_dist < old_dist: reward = 10 # Positive reward for moving closer to the target
                elif new_dist > old_dist: reward = -5 # Negative penalty for moving farther away

            # Update Q-Table 
            new_state = self.get_state(target_coin) # Calculates the state in the new position
            if new_state not in self.q_table:
                self.q_table[new_state] = [0, 0, 0, 0] # Initializes the new state if it's the first visit

            max_future_q = max(self.q_table[new_state]) # Finds the best Q-value in the new state
            current_q = self.q_table[state][action] # The Q-value being updated
            # The core Q-Learning formula: Q(s,a) = Q(s,a) + alpha * (reward + gamma * max(Q(s',a')) - Q(s,a))
            self.q_table[state][action] = current_q + self.alpha * (reward + self.gamma * max_future_q - current_q)

            self.target_pixel = [self.grid_pos[0] * CELL_SIZE, self.grid_pos[1] * CELL_SIZE] # Sets the new pixel target

    def move_towards(self, target, walls):
        tx, ty = target # Target grid coordinates
        gx, gy = self.grid_pos # Current grid coordinates

        moves = [] # List of preferred moves 
        if gx < tx: moves.append([1, 0]) # Prioritize moving right
        elif gx > tx: moves.append([-1, 0]) # Prioritize moving left
        if gy < ty: moves.append([0, 1]) # Prioritize moving down
        elif gy > ty: moves.append([0, -1]) # Prioritize moving up

        moved = False # Flag to check if a move was successful
        for mx, my in moves: # Tries the preferred moves first
            nx, ny = gx + mx, gy + my # New potential position
            if [nx, ny] not in walls and [nx, ny] != self.previous_pos: # Checks if the path is clear and not backtracking
                self.add_trail_point() # Records the old position
                self.previous_pos = self.grid_pos[:] # Saves the current position as the previous one
                self.grid_pos = [nx, ny] # Updates to the new position
                moved = True # Move was successful
                break # Stops checking other preferred moves

        if not moved: # If no preferred move was possible
            opts = [[0,1], [0,-1], [1,0], [-1,0]] # All possible directional moves
            random.shuffle(opts) # Shuffles them to try a random unblocked path
            for ox, oy in opts: # Tries an alternative move
                nx, ny = gx + ox, gy + oy
                # Checks bounds, walls, and no backtracking
                if ([nx, ny] not in walls and 0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE and [nx, ny] != self.previous_pos):
                    self.add_trail_point() # Records the old position
                    self.previous_pos = self.grid_pos[:] # Saves the current position
                    self.grid_pos = [nx, ny] # Updates to the new position
                    break # Stops checking other alternatives

        self.target_pixel = [self.grid_pos[0] * CELL_SIZE, self.grid_pos[1] * CELL_SIZE] # Sets the new pixel target

    def draw(self, surface):
        # DRAW TRAIL
        if len(self.trail) > 1: # Only draw a line if there are at least two points
            pygame.draw.lines(surface, self.color, False, self.trail, 2) # Draws the path the agent has taken

        # Draw line from last trail point to current robot for continuity
        if self.trail: # If there is a trail
            last_pt = self.trail[-1] # Gets the last recorded cell center
            curr_pt = (self.pixel_pos[0] + CELL_SIZE//2, self.pixel_pos[1] + CELL_SIZE//2) # Gets the robot's current pixel center
            pygame.draw.line(surface, self.color, last_pt, curr_pt, 2) # Draws a line to connect the last cell and the robot

        # Draw Robot
        # Draws a small shadow under the robot for depth
        pygame.draw.ellipse(surface, (0,0,0), (self.pixel_pos[0]+4, self.pixel_pos[1]+28, 32, 10))
        surface.blit(self.image, (self.pixel_pos[0]+2, self.pixel_pos[1]+2)) # Draws the robot image on top of the shadow

# --- MAIN ---
class SimulationApp:
    def __init__(self):
        pygame.init() # Initializes all Pygame modules
        pygame.mixer.init() # Initializes the sound mixer module

        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) 
        pygame.display.set_caption("A.I. Swarm Robotics Simulation v2.0") 
        self.clock = pygame.time.Clock() 

        self.sound_manager = SoundManager() # Creates the sound management object

        # Fonts
        self.title_font = load_custom_font(55) 
        self.menu_font = load_custom_font(24) 
        self.ui_font = load_custom_font(14) 
        self.score_font = load_custom_font(28) 
        self.end_font = load_custom_font(30)

        self.coin_img = load_and_prep_image("coin.png", 28) 

        self.particles = [] # List to hold active particle effects
        self.state = "MENU" # Initial state of the application (menu, play, gameover)
        self.bg_offset = 0 # Used for the scrolling background effect on the menu

        self.reset_game() # Initializes all game-specific elements

    def reset_game(self):
        self.walls = self.gen_walls(50) # Generates 50 random wall positions
        self.coins = self.gen_coins(25) # Generates 25 random coin positions
        # --- ASSIGNING STRATEGIES ---
        self.agents = [ # Creates the three agents with their unique strategies
            Agent(2, 2,   "red_robot.png",   "RED-01 (Greedy)", C_RED, "greedy"), # Agent uses the simple Greedy strategy
            Agent(15, 2,  "blue_robot.png",  "BLUE-01 (Coop)",  C_BLUE, "coop"), # Agent uses the Cooperative (anti-collision) strategy
            Agent(2, 15,  "green_robot.png", "GRN-01 (AI Learn)", C_GREEN, "learning") # Agent uses the Q-Learning strategy
        ]
        self.move_timer = 0 # Timer to control agent movement rate
        self.sim_time = 0 # Tracks the simulation time

    def gen_walls(self, count):
        walls = [] # Initializes the list of walls
        for _ in range(count): # Repeats 'count' number of times
            pos = [random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)] # Picks a random grid position
            # Ensures walls don't block the agents' starting positions
            if pos not in [[2,2], [15,2], [2,15]]: walls.append(pos) # Adds the position if it's not a starting spot
        return walls # Returns the list of wall positions

    def gen_coins(self, count):
        coins = [] # Initializes the list of coins
        while len(coins) < count: # Loops until the required number of coins is generated
            pos = [random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)] # Picks a random grid position
            # Ensures coins aren't on top of existing coins, walls, or agent starting positions
            if pos not in coins and pos not in self.walls and pos not in [[2,2], [15,2], [2,15]]:
                coins.append(pos) # Adds the position if it's a valid spot
        return coins # Returns the list of coin positions

    def spawn_particles(self, x, y, color):
        for _ in range(10): # Creates 10 particles
            self.particles.append(Particle(x + CELL_SIZE//2, y + CELL_SIZE//2, color)) # Adds a new particle at the center of the cell

    def update(self):
        self.bg_offset = (self.bg_offset + 0.5) % CELL_SIZE # Scrolls the background grid by a small amount

        for p in self.particles[:]: # Loops through particles (using a slice allows safe removal)
            p.update() # Updates the particle's position and life
            if p.life <= 0: self.particles.remove(p) # Removes the particle if its life runs out

        for agent in self.agents:
            agent.update_visuals() # Updates the agent's smooth pixel position

        if self.state == "PLAY": # Checks if the simulation is running
            self.move_timer += 1 # Increments the move timer
            if self.move_timer > 10: # Agents move every 10 update cycles (controls simulation speed)
                self.move_timer = 0 # Resets the timer
                self.sim_time += 0.15 # Increments the simulated time

                for agent in self.agents: # Gives each agent a chance to move
                    agent.think_and_move(self.coins, self.agents, self.walls) # Agent decides its next move based on its strategy

                    if agent.grid_pos in self.coins: # Checks if the agent landed on a coin
                        self.coins.remove(agent.grid_pos) # Removes the coin from the map
                        agent.score += 10 # Increases the agent's score
                        # Spawns gold particles at the coin's location
                        self.spawn_particles(agent.grid_pos[0]*CELL_SIZE, agent.grid_pos[1]*CELL_SIZE, C_GOLD)
                        self.sound_manager.play('pickup') # Plays the coin pickup sound

                if not self.coins: # Checks if all coins have been collected
                    self.state = "GAMEOVER" # Changes the state to end the simulation
                    self.sound_manager.play('complete') # Plays the completion sound

    def draw_background_grid(self):
        for x in range(0, SCREEN_WIDTH, CELL_SIZE): # Draws vertical lines across the entire screen
            color = (20, 30, 50)
            pygame.draw.line(self.screen, color, (x, 0), (x, SCREEN_HEIGHT))

        for y in range(0, SCREEN_HEIGHT + CELL_SIZE, CELL_SIZE): # Draws horizontal lines with offset
            draw_y = y + (self.bg_offset % CELL_SIZE) - CELL_SIZE # Calculates the offset for the scrolling effect
            color = (20, 30, 50)
            pygame.draw.line(self.screen, color, (0, draw_y), (SCREEN_WIDTH, draw_y))

    def draw_menu(self):
        self.screen.fill(C_BG) # Clears the screen with the background color
        self.draw_background_grid() # Draws the scrolling menu background

        title_txt = "MULTI-AGENT SWARM"
        draw_glow_text(self.screen, title_txt, self.title_font, C_ACCENT, (SCREEN_WIDTH//2, SCREEN_HEIGHT//3), C_BLUE)

        sub_txt = "RESOURCE COLLECTION SIMULATION"
        sub_surf = self.ui_font.render(sub_txt, True, (150, 180, 200)) 
        self.screen.blit(sub_surf, sub_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//3 + 50)))

        btn_text_str = "START SIMULATION"
        text_surf = self.menu_font.render(btn_text_str, True, C_BG) 

        text_w = text_surf.get_width()
        text_h = text_surf.get_height()
        pad_x = 60 
        pad_y = 30

        btn_rect = pygame.Rect(0, 0, text_w + pad_x, text_h + pad_y)
        btn_rect.center = (SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 40) 

        # Creates a pulsing effect for the glow
        pulse = (math.sin(pygame.time.get_ticks() * 0.005) + 1) / 2
        glow_alpha = int(100 + (pulse * 155)) # Calculates the fading transparency level

        glow_surf = pygame.Surface((btn_rect.width + 10, btn_rect.height + 10), pygame.SRCALPHA) # Creates a transparent surface for the glow
        pygame.draw.rect(glow_surf, (*C_ACCENT, max(50, glow_alpha//3)), glow_surf.get_rect(), border_radius=15) 
        self.screen.blit(glow_surf, (btn_rect.x - 5, btn_rect.y - 5)) 

        pygame.draw.rect(self.screen, C_ACCENT, btn_rect, border_radius=10) 
        pygame.draw.rect(self.screen, (255, 255, 255), btn_rect, 2, border_radius=10) 
        self.screen.blit(text_surf, text_surf.get_rect(center=btn_rect.center))

        inst = self.ui_font.render("PRESS [SPACE] TO INITIALIZE", True, C_TEXT) 
        self.screen.blit(inst, inst.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT - 80))) 

    def draw_game(self):
        self.screen.fill(C_BG) 

        # Draw Grid
        for x in range(GRID_SIZE + 1): # Draws vertical lines for the grid map
            pygame.draw.line(self.screen, C_GRID, (x*CELL_SIZE, 0), (x*CELL_SIZE, MAP_HEIGHT))
        for y in range(GRID_SIZE + 1): # Draws horizontal lines for the grid map
            pygame.draw.line(self.screen, C_GRID, (0, y*CELL_SIZE), (MAP_WIDTH, y*CELL_SIZE))

        # Draw Walls
        for w in self.walls: 
            rect = (w[0]*CELL_SIZE, w[1]*CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(self.screen, C_WALL, rect)
            pygame.draw.rect(self.screen, C_WALL_EDGE, rect, 2) 

        
        bob_offset = math.sin(pygame.time.get_ticks() * 0.005) * 3
        for c in self.coins: 
            self.screen.blit(self.coin_img, (c[0]*CELL_SIZE + 6, c[1]*CELL_SIZE + 6 + bob_offset))

        # Draw Agents
        for agent in self.agents:
            agent.draw(self.screen) 

        # Draw Particles
        for p in self.particles:
            p.draw(self.screen) # Draws all active particle effects

        # DASHBOARD
        #Dashboard design
        panel_rect = (MAP_WIDTH, 0, SCREEN_WIDTH - MAP_WIDTH, SCREEN_HEIGHT) 
        pygame.draw.rect(self.screen, C_PANEL, panel_rect) 
        pygame.draw.line(self.screen, C_ACCENT, (MAP_WIDTH, 0), (MAP_WIDTH, SCREEN_HEIGHT), 3) 

        header = self.score_font.render("LIVE STATS", True, C_TEXT) 
        self.screen.blit(header, (MAP_WIDTH + 20, 30)) 

        time_txt = self.ui_font.render(f"Time: {self.sim_time:.1f}s", True, C_ACCENT) 
        self.screen.blit(time_txt, (MAP_WIDTH + 20, 80)) 

        coin_txt = self.ui_font.render(f"Coins Left: {len(self.coins)}", True, C_GOLD) 
        self.screen.blit(coin_txt, (MAP_WIDTH + 20, 110)) 

        y_offset = 180 
        for agent in self.agents: # Loops through all agents to display their stats
            # Draws a background box for the agent's stats
            pygame.draw.rect(self.screen, (30, 35, 50), (MAP_WIDTH + 20, y_offset, 240, 100), border_radius=8)
            # Draws a colored stripe to match the agent's color
            pygame.draw.rect(self.screen, agent.color, (MAP_WIDTH + 20, y_offset, 5, 100), border_radius=8)

            name_txt = self.ui_font.render(agent.name, True, agent.color) 
            self.screen.blit(name_txt, (MAP_WIDTH + 40, y_offset + 10))

            score_txt = self.score_font.render(str(agent.score), True, (255,255,255)) # Renders the agent's score
            self.screen.blit(score_txt, (MAP_WIDTH + 220 - score_txt.get_width(), y_offset + 30)) # Draws the score on the right side

            strat_txt = self.ui_font.render(f"Mode: {agent.strategy.upper()}", True, (150, 150, 150)) # Renders the agent's strategy mode
            self.screen.blit(strat_txt, (MAP_WIDTH + 40, y_offset + 60))

            y_offset += 120 # Moves the next agent's stat box down

        # GAME OVER 
        if self.state == "GAMEOVER":
            overlay = pygame.Surface((MAP_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA) # Creates a semi-transparent surface
            overlay.fill((0, 0, 0, 180)) 
            self.screen.blit(overlay, (0,0)) # Draws the overlay over the map

            end_txt = self.end_font.render("SIMULATION COMPLETE", True, C_ACCENT)
            self.screen.blit(end_txt, end_txt.get_rect(center=(MAP_WIDTH//2, SCREEN_HEIGHT//2 - 50))) 

            press_txt = self.ui_font.render("Press [R] to Reset Simulation", True, C_TEXT)
            self.screen.blit(press_txt, press_txt.get_rect(center=(MAP_WIDTH//2, SCREEN_HEIGHT//2 + 20)))

    def run(self):
        running = True # Loop control flag
        while running: # Main game loop
            self.clock.tick(60) # Limits the frame rate to 60 FPS

            for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    running = False # Exits the main loop

                if event.type == pygame.KEYDOWN: # Handles key presses
                    if event.key == pygame.K_ESCAPE: running = False
                    if self.state == "MENU" and event.key == pygame.K_SPACE: # Spacebar starts the game from the menu
                        self.state = "PLAY" # Changes state to start the simulation
                        self.sound_manager.play('start') # Plays the start sound
                    if self.state == "GAMEOVER" and event.key == pygame.K_r: # 'R' key resets the game from the gameover screen
                        self.reset_game() # Re-initializes all game components
                        self.state = "MENU" # Returns to the main menu

                if event.type == pygame.MOUSEBUTTONDOWN: # Handles mouse clicks
                    if self.state == "MENU": # Clicking also starts the game from the menu
                        self.state = "PLAY" # Changes state to start the simulation
                        self.sound_manager.play('start') # Plays the start sound

            self.update() 

            if self.state == "MENU": 
                self.draw_menu() 
            else: # 
                self.draw_game()

            pygame.display.flip() # Updates the entire screen to show the new frame

        pygame.quit() # Uninitializes Pygame modules
        sys.exit() # Exits the application

if __name__ == "__main__":
    app = SimulationApp() # Creates an instance of the main application class
    app.run() # Starts the main game loop
